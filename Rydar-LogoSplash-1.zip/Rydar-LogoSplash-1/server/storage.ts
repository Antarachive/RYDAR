import { db } from "./db";
import {
  users, buses, trips, tickets,
  type User, type InsertUser, type Bus, type Trip, type Ticket,
  type CreateTicketRequest
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { createHash } from "crypto";

export interface IStorage {
  // Auth
  getUser(id: number): Promise<User | undefined>;
  getUserByCamuId(camuId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Buses & Trips
  getBuses(): Promise<Bus[]>;
  getBus(id: number): Promise<Bus | undefined>;
  getTrips(): Promise<(Trip & { bus: Bus })[]>;
  getTrip(id: number): Promise<Trip | undefined>;
  
  // Tickets
  getTickets(userId: number): Promise<(Ticket & { trip: Trip, holder: User })[]>;
  createTicket(userId: number, request: CreateTicketRequest): Promise<Ticket>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByCamuId(camuId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.camuId, camuId));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getBuses(): Promise<Bus[]> {
    return await db.select().from(buses);
  }

  async getBus(id: number): Promise<Bus | undefined> {
    const [bus] = await db.select().from(buses).where(eq(buses.id, id));
    return bus;
  }

  async getTrips(): Promise<(Trip & { bus: Bus })[]> {
    // Drizzle currently needs explicit joins for type inference in many cases, 
    // or we can use query builder. using query.trips.findMany is easier usually 
    // but here we are using standard select.
    const result = await db.select({
      trip: trips,
      bus: buses,
    })
    .from(trips)
    .innerJoin(buses, eq(trips.busId, buses.id));
    
    return result.map(r => ({ ...r.trip, bus: r.bus }));
  }

  async getTrip(id: number): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.id, id));
    return trip;
  }

  async getTickets(userId: number): Promise<(Ticket & { trip: Trip, holder: User })[]> {
    // Get tickets purchased by user OR held by user
    const result = await db.select({
      ticket: tickets,
      trip: trips,
      holder: users,
    })
    .from(tickets)
    .innerJoin(trips, eq(tickets.tripId, trips.id))
    .innerJoin(users, eq(tickets.holderId, users.id))
    .where(eq(tickets.userId, userId)); // Simplification: only show bought tickets for now

    return result.map(r => ({ ...r.ticket, trip: r.trip, holder: r.holder }));
  }

  async createTicket(userId: number, request: CreateTicketRequest): Promise<Ticket> {
    let holderId = userId;
    
    // If booking for someone else
    if (request.holderCamuId) {
      const holder = await this.getUserByCamuId(request.holderCamuId);
      if (holder) {
        holderId = holder.id;
      }
      // If holder not found, fail or default to self? 
      // For MVP, if not found, throw error or assume self. 
      // Let's assume passed ID is valid for now or validated at route layer.
    }

    // Generate Mock Blockchain Hash
    const rawString = `${userId}-${request.tripId}-${Date.now()}`;
    const blockchainHash = createHash('sha256').update(rawString).digest('hex');
    const qrCode = `RYDAR:${blockchainHash}`;

    const [ticket] = await db.insert(tickets).values({
      userId,
      holderId,
      tripId: request.tripId,
      blockchainHash,
      qrCode,
      price: 50, // Mock price
      status: "booked"
    }).returning();

    return ticket;
  }
}

export const storage = new DatabaseStorage();
