import type { Express } from "express";
import type { Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { db } from "./db";
import * as schema from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth (Custom simple auth for "Camu")
  setupAuth(app);

  // Buses
  app.get(api.buses.list.path, async (req, res) => {
    const buses = await storage.getBuses();
    res.json(buses);
  });

  app.get(api.buses.get.path, async (req, res) => {
    const bus = await storage.getBus(Number(req.params.id));
    if (!bus) return res.status(404).json({ message: "Bus not found" });
    res.json(bus);
  });

  // Trips
  app.get(api.trips.list.path, async (req, res) => {
    const trips = await storage.getTrips();
    res.json(trips);
  });

  // Tickets
  app.get(api.tickets.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const tickets = await storage.getTickets(req.user.id);
    res.json(tickets);
  });

  app.post(api.tickets.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.tickets.create.input.parse(req.body);
      const ticket = await storage.createTicket(req.user.id, input);
      res.status(201).json(ticket);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  return httpServer;
}

// Simple seed function to run on startup if empty
async function seed() {
  const buses = await storage.getBuses();
  if (buses.length === 0) {
    console.log("Seeding database...");
    
    // Create buses
    await db.insert(schema.buses).values([
      { vehicleNumber: "BUS-001", type: "standard", capacity: 40, status: "active" },
      { vehicleNumber: "BUS-002", type: "standard", capacity: 40, status: "active" },
      { vehicleNumber: "VEN-101", type: "vendor", capacity: 30, status: "active" },
    ]);

    const newBuses = await storage.getBuses();
    
    // Create Trips
    await db.insert(schema.trips).values([
      { busId: newBuses[0].id, routeId: "ROUTE-A", status: "scheduled", startTime: new Date() },
      { busId: newBuses[1].id, routeId: "ROUTE-B", status: "in_progress", startTime: new Date() },
      { busId: newBuses[2].id, routeId: "ROUTE-C", status: "scheduled", startTime: new Date() },
    ]);
    
    // Create Admin User
    await storage.createUser({
      camuId: "ADMIN001",
      password: "admin", // Plaintext for MVP demo only
      fullName: "Transport Officer",
      role: "admin",
    });

    // Create Student
    await storage.createUser({
      camuId: "STU12345",
      password: "pass",
      fullName: "John Doe",
      role: "student",
    });

    console.log("Seeding complete.");
  }
}

// Run seed
seed().catch(console.error);
