import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === USERS (Student/Staff/Admin) ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  camuId: text("camu_id").notNull().unique(), // The "Student ID"
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("student"), // student, staff, admin
  greenPoints: integer("green_points").default(0),
});

// === BUSES ===
export const buses = pgTable("buses", {
  id: serial("id").primaryKey(),
  vehicleNumber: text("vehicle_number").notNull().unique(),
  capacity: integer("capacity").default(40),
  currentOccupancy: integer("current_occupancy").default(0),
  status: text("status").default("active"), // active, maintenance
  type: text("type").default("standard"), // standard, vendor
  lat: text("lat"), // Current GPS lat
  lng: text("lng"), // Current GPS lng
});

// === TRIPS ===
export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  busId: integer("bus_id").references(() => buses.id).notNull(),
  routeId: text("route_id").notNull(),
  status: text("status").default("scheduled"), // scheduled, in_progress, completed, cancelled
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
});

// === TICKETS (Blockchain Backed) ===
export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(), // Purchaser
  holderId: integer("holder_id").references(() => users.id), // Actual traveler (if different)
  tripId: integer("trip_id").references(() => trips.id).notNull(),
  status: text("status").default("booked"), // booked, charged, boarded, completed
  blockchainHash: text("blockchain_hash").notNull(), // SHA256 Mock
  qrCode: text("qr_code").notNull(),
  price: integer("price").notNull(), // In cents/paise
  purchasedAt: timestamp("purchased_at").defaultNow(),
});

// === RELATIONS ===
export const usersRelations = relations(users, ({ many }) => ({
  tickets: many(tickets, { relationName: "purchaser" }),
}));

export const busesRelations = relations(buses, ({ many }) => ({
  trips: many(trips),
}));

export const tripsRelations = relations(trips, ({ one, many }) => ({
  bus: one(buses, {
    fields: [trips.busId],
    references: [buses.id],
  }),
  tickets: many(tickets),
}));

export const ticketsRelations = relations(tickets, ({ one }) => ({
  trip: one(trips, {
    fields: [tickets.tripId],
    references: [trips.id],
  }),
  user: one(users, {
    fields: [tickets.userId],
    references: [users.id],
    relationName: "purchaser",
  }),
  holder: one(users, {
    fields: [tickets.holderId],
    references: [users.id],
  }),
}));

// === ZOD SCHEMAS ===
export const insertUserSchema = createInsertSchema(users).omit({ id: true, greenPoints: true });
export const insertBusSchema = createInsertSchema(buses).omit({ id: true, currentOccupancy: true });
export const insertTripSchema = createInsertSchema(trips).omit({ id: true });
export const insertTicketSchema = createInsertSchema(tickets).omit({ 
  id: true, 
  blockchainHash: true, 
  qrCode: true, 
  purchasedAt: true 
});

// === EXPLICIT TYPES ===
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Bus = typeof buses.$inferSelect;
export type Trip = typeof trips.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;

export type LoginRequest = { camuId: string; password: string };
export type AuthResponse = User;

export type CreateTicketRequest = {
  tripId: number;
  holderCamuId?: string; // Optional: book for someone else
};
