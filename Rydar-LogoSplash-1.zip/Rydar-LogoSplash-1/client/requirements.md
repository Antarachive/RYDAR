## Packages
framer-motion | Essential for the "Scale-In" splash animation and smooth transitions
react-qr-code | To generate QR codes for tickets
google-map-react | For the live bus tracking visualization (using a simple placeholder if API key missing)
lucide-react | Already in base, but emphasizing heavily for UI icons

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}
Tailwind Config - extend colors:
colors: {
  ivory: "hsl(var(--ivory))",
  burgundy: "hsl(var(--burgundy))",
  sapphire: "hsl(var(--sapphire))",
}
