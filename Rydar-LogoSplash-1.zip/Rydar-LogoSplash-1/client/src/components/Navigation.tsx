import { Link, useLocation } from "wouter";
import { RydarLogo } from "./RydarLogo";
import { useUser, useLogout } from "@/hooks/use-auth";
import { Home, Map, Ticket, LogOut, Box } from "lucide-react";
import { Button } from "./ui/button";

export function Navigation() {
  const [location] = useLocation();
  const { data: user } = useUser();
  const { mutate: logout } = useLogout();

  if (!user) return null;

  const isAdmin = user.role === "admin";

  const navItems = [
    { href: "/dashboard", icon: Home, label: "Home" },
    { href: "/map", icon: Map, label: "Voyage" },
    ...(isAdmin ? [{ href: "/admin", icon: Box, label: "Fleet" }] : []),
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-ivory/80 backdrop-blur-md border-b border-sapphire/10 h-16">
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        <Link href="/dashboard" className="flex items-center gap-3 cursor-pointer group">
          <div className="w-8 h-8 group-hover:scale-110 transition-transform duration-300">
            <RydarLogo animate={true} />
          </div>
          <span className="font-display font-bold text-xl text-sapphire tracking-wider hidden sm:block">
            RYDAR
          </span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div 
                className={`
                  p-2 sm:px-4 sm:py-2 rounded-lg flex items-center gap-2 cursor-pointer transition-all duration-200
                  ${location === item.href 
                    ? 'bg-sapphire text-ivory shadow-lg shadow-sapphire/20 translate-y-[-1px]' 
                    : 'text-sapphire/60 hover:bg-sapphire/5 hover:text-sapphire'}
                `}
              >
                <item.icon className="w-5 h-5" />
                <span className="hidden sm:inline font-medium text-sm">{item.label}</span>
              </div>
            </Link>
          ))}
          
          <div className="w-px h-6 bg-sapphire/10 mx-2" />
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => logout()}
            className="text-burgundy hover:bg-burgundy/10 hover:text-burgundy rounded-lg"
          >
            <LogOut className="w-5 h-5" />
          </Button>
        </nav>
      </div>
    </header>
  );
}
