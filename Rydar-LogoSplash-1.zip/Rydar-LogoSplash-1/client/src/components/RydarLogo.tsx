import { motion } from "framer-motion";

interface RydarLogoProps {
  className?: string;
  animate?: boolean;
}

export function RydarLogo({ className = "", animate = false }: RydarLogoProps) {
  // Use uploaded logo if present, else fallback to CSS shapes
  // Assuming logo might be at /rydar_logo.png
  
  const pulseVariant = {
    initial: { scale: 1, opacity: 0.5 },
    animate: { 
      scale: [1, 1.2, 1], 
      opacity: [0.5, 0.8, 0.5],
      transition: { duration: 2, repeat: Infinity, ease: "easeInOut" } 
    }
  };
  
  const rotateVariant = {
    animate: {
      rotate: 360,
      transition: { duration: 8, repeat: Infinity, ease: "linear" }
    }
  };

  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* Fallback geometric logo construction if image fails to load or as decoration */}
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Outer Ring - Sapphire */}
        <motion.div 
          className="absolute inset-0 border-2 border-[hsl(var(--sapphire))] rounded-full opacity-30"
          variants={animate ? rotateVariant : {}}
          animate={animate ? "animate" : ""}
          style={{ borderStyle: 'dashed' }}
        />
        
        {/* Middle Pulse Ring - Burgundy */}
        <motion.div 
          className="absolute inset-[15%] border-2 border-[hsl(var(--burgundy))] rounded-full"
          variants={animate ? pulseVariant : {}}
          initial="initial"
          animate={animate ? "animate" : ""}
        />

        {/* Center Core */}
        <div className="absolute inset-[35%] bg-[hsl(var(--sapphire))] rounded-full flex items-center justify-center text-ivory font-display font-bold text-[10px] md:text-xs tracking-widest">
          R
        </div>

        {/* Try to load actual image on top if available */}
        <img 
          src="/rydar_logo.png" 
          alt="Rydar Logo" 
          className="absolute inset-0 w-full h-full object-contain p-1"
          onError={(e) => { e.currentTarget.style.display = 'none'; }} 
        />
      </div>
    </div>
  );
}
