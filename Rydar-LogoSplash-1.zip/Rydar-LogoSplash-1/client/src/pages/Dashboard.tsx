import { useUser } from "@/hooks/use-auth";
import { useTickets, useCreateTicket } from "@/hooks/use-tickets";
import { useTrips } from "@/hooks/use-trips";
import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { QRCodeSVG } from "qrcode.react";
import { motion } from "framer-motion";
import { Loader2, Ticket as TicketIcon, MapPin, Calendar, Leaf } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import type { Trip, Bus } from "@shared/schema";

// Ticket Component
function TicketCard({ ticket }: { ticket: any }) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white rounded-xl shadow-lg border border-sapphire/10 overflow-hidden flex flex-col md:flex-row relative"
    >
      {/* Decorative Status Strip */}
      <div className={`
        h-2 md:h-auto md:w-2 
        ${ticket.status === 'booked' ? 'bg-burgundy' : 'bg-green-500'}
      `} />
      
      <div className="p-6 flex-1">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-display text-sapphire">{ticket.trip.routeId}</h3>
            <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
              <Calendar className="w-3 h-3" />
              {ticket.trip.startTime ? format(new Date(ticket.trip.startTime), "PP p") : "Scheduled"}
            </p>
          </div>
          <Badge variant={ticket.status === 'booked' ? 'destructive' : 'default'} className="uppercase tracking-widest text-[10px]">
            {ticket.status}
          </Badge>
        </div>
        
        <div className="flex items-center gap-4 mt-6 pt-6 border-t border-dashed border-gray-200">
           <div className="bg-white p-2 rounded-lg shadow-sm border border-gray-100">
             <QRCodeSVG value={ticket.qrCode} size={64} level="L" />
           </div>
           <div className="flex-1 overflow-hidden">
             <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-wider">BLOCKCHAIN HASH</p>
             <p className="font-mono text-[10px] text-sapphire/70 break-all leading-tight mt-1">
               {ticket.blockchainHash}
             </p>
           </div>
        </div>
      </div>
      
      {/* Punch out circles for ticket effect */}
      <div className="absolute top-1/2 -left-3 w-6 h-6 bg-ivory rounded-full" />
      <div className="absolute top-1/2 -right-3 w-6 h-6 bg-ivory rounded-full" />
    </motion.div>
  );
}

// Quick Book Component
function QuickBook({ trips }: { trips: (Trip & { bus: Bus })[] }) {
  const { mutate: createTicket, isPending } = useCreateTicket();
  const { toast } = useToast();

  const handleBook = (tripId: number) => {
    createTicket({ tripId }, {
      onSuccess: () => {
        toast({ title: "Booking Confirmed", description: "Your ticket has been generated." });
      },
      onError: (err) => {
        toast({ title: "Booking Failed", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <Card className="p-6 bg-white/60 backdrop-blur border-sapphire/10 shadow-xl">
      <h2 className="text-xl font-display text-sapphire mb-6 flex items-center gap-2">
        <TicketIcon className="w-5 h-5 text-burgundy" />
        QUICK BOOK
      </h2>
      
      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
        {trips?.filter(t => t.status === 'scheduled').map(trip => (
          <div key={trip.id} className="group p-4 rounded-xl border border-sapphire/5 bg-white hover:border-sapphire/20 transition-all flex items-center justify-between">
            <div>
              <div className="font-bold text-sapphire">{trip.routeId}</div>
              <div className="text-xs text-muted-foreground mt-1 font-mono">
                BUS #{trip.bus.vehicleNumber} • {trip.bus.type.toUpperCase()}
              </div>
            </div>
            <Button 
              size="sm" 
              onClick={() => handleBook(trip.id)}
              disabled={isPending}
              className="bg-sapphire hover:bg-sapphire/90 text-ivory font-display text-xs tracking-wider"
            >
              {isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : "BOOK"}
            </Button>
          </div>
        ))}
        {trips?.length === 0 && (
          <div className="text-center py-8 text-muted-foreground text-sm">No scheduled trips available.</div>
        )}
      </div>
    </Card>
  );
}

export default function Dashboard() {
  const { data: user } = useUser();
  const { data: tickets, isLoading: loadingTickets } = useTickets();
  const { data: trips, isLoading: loadingTrips } = useTrips();

  if (loadingTickets || loadingTrips) return <div className="flex justify-center p-20"><Loader2 className="animate-spin w-8 h-8 text-sapphire" /></div>;

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* User Profile & Stats */}
        <div className="lg:col-span-3">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row justify-between items-end gap-4 mb-8"
          >
            <div>
              <h1 className="text-4xl font-display text-sapphire">HELLO, {user?.fullName.split(' ')[0]}</h1>
              <p className="text-muted-foreground font-mono mt-1 flex items-center gap-2">
                ID: {user?.camuId} <span className="text-sapphire/20">|</span> <span className="uppercase">{user?.role}</span>
              </p>
            </div>
            
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-2xl shadow-lg shadow-emerald-500/20 flex items-center gap-3">
              <div className="bg-white/20 p-2 rounded-full">
                <Leaf className="w-5 h-5" />
              </div>
              <div>
                <div className="text-2xl font-bold font-display leading-none">{user?.greenPoints || 0}</div>
                <div className="text-[10px] font-bold tracking-widest opacity-80">GREEN POINTS</div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Active Tickets */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-display text-sapphire tracking-wide">ACTIVE TICKETS</h2>
          </div>
          
          <div className="grid gap-4">
            {tickets?.map((ticket) => (
              <TicketCard key={ticket.id} ticket={ticket} />
            ))}
            {tickets?.length === 0 && (
              <div className="border-2 border-dashed border-sapphire/10 rounded-2xl p-12 text-center">
                <TicketIcon className="w-12 h-12 text-sapphire/20 mx-auto mb-4" />
                <p className="text-muted-foreground font-mono text-sm">NO ACTIVE TICKETS FOUND</p>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="lg:col-span-1">
           <QuickBook trips={trips || []} />
        </div>
      </div>
    </Layout>
  );
}
