import { useBuses } from "@/hooks/use-buses";
import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Bus as BusIcon, AlertTriangle, CheckCircle } from "lucide-react";
import type { Bus } from "@shared/schema";

// The "Box" component representing a bus
// "Balls" inside represent passengers (capacity vs occupancy)
function BusBox({ bus }: { bus: Bus }) {
  // Visual calculation for "balls"
  // Let's say max 40 balls fit in the box visually
  const maxVisual = 20;
  const occupancyRatio = (bus.currentOccupancy || 0) / (bus.capacity || 40);
  const ballCount = Math.ceil(occupancyRatio * maxVisual);

  return (
    <motion.div 
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="bg-white rounded-2xl p-6 shadow-xl border border-sapphire/10 hover:shadow-2xl transition-all"
    >
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-3">
          <div className="bg-sapphire/10 p-2 rounded-lg">
            <BusIcon className="w-6 h-6 text-sapphire" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-sapphire">#{bus.vehicleNumber}</h3>
            <p className="text-xs text-muted-foreground uppercase tracking-wide">{bus.type}</p>
          </div>
        </div>
        <Badge variant={bus.status === 'active' ? 'default' : 'destructive'}>
          {bus.status === 'active' ? <CheckCircle className="w-3 h-3 mr-1" /> : <AlertTriangle className="w-3 h-3 mr-1" />}
          {bus.status}
        </Badge>
      </div>

      {/* The Box Visualization */}
      <div className="relative h-32 bg-gray-50 rounded-xl border-2 border-dashed border-gray-200 overflow-hidden flex flex-wrap content-end p-2 gap-1">
        {Array.from({ length: ballCount }).map((_, i) => (
           <motion.div 
             key={i}
             initial={{ y: -50, opacity: 0 }}
             animate={{ y: 0, opacity: 1 }}
             transition={{ delay: i * 0.05, type: "spring" }}
             className="w-4 h-4 rounded-full bg-burgundy shadow-sm"
           />
        ))}
        {/* Remaining Capacity Hint */}
        <div className="absolute top-2 right-3 text-xs font-mono text-gray-400">
           {bus.currentOccupancy} / {bus.capacity} PAX
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-mono text-muted-foreground">
        <div className="bg-gray-50 p-2 rounded">
          LAT: {Number(bus.lat).toFixed(4) || "---"}
        </div>
        <div className="bg-gray-50 p-2 rounded">
          LNG: {Number(bus.lng).toFixed(4) || "---"}
        </div>
      </div>
    </motion.div>
  );
}

export default function AdminFleet() {
  const { data: buses, isLoading } = useBuses();

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-display text-sapphire">FLEET COMMAND</h1>
        <p className="text-muted-foreground">Real-time occupancy and status monitoring.</p>
      </div>

      {isLoading ? (
        <div className="text-center p-20">Loading Fleet Data...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {buses?.map(bus => (
            <BusBox key={bus.id} bus={bus} />
          ))}
        </div>
      )}
    </Layout>
  );
}
