import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { useBuses } from "@/hooks/use-buses";
import GoogleMapReact from 'google-map-react';
import { motion } from "framer-motion";
import { Bus, University, Smartphone } from "lucide-react";
import type { Bus as BusType } from "@shared/schema";

// --- Map Markers ---

const UserMarker = () => (
  <div className="relative flex items-center justify-center w-8 h-8 -ml-4 -mt-4">
    <div className="absolute inset-0 bg-burgundy rounded-full opacity-20 animate-ping" />
    <div className="bg-burgundy text-white p-2 rounded-full shadow-lg border-2 border-white">
      <Smartphone className="w-4 h-4" />
    </div>
  </div>
);

const BusMarker = ({ bus }: { bus: BusType }) => (
  <motion.div 
    initial={{ scale: 0 }} 
    animate={{ scale: 1 }}
    className="relative flex flex-col items-center -ml-5 -mt-10 group cursor-pointer"
  >
    <div className="relative z-10 bg-sapphire text-white p-2 rounded-xl shadow-xl border-2 border-ivory group-hover:scale-110 transition-transform">
      <Bus className="w-5 h-5" />
    </div>
    {/* Concentric Radar Rings */}
    <div className="absolute top-2 left-2 w-full h-full border border-sapphire/30 rounded-full animate-[ping_3s_linear_infinite]" />
    
    <div className="mt-1 px-2 py-1 bg-white/90 backdrop-blur rounded text-[10px] font-bold text-sapphire shadow-sm opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
      BUS #{bus.vehicleNumber}
    </div>
  </motion.div>
);

const UniMarker = () => (
  <div className="relative flex items-center justify-center -ml-6 -mt-6">
    <div className="bg-ivory text-sapphire p-3 rounded-full shadow-xl border-2 border-sapphire">
      <University className="w-6 h-6" />
    </div>
    <div className="absolute -bottom-6 text-xs font-bold bg-sapphire text-white px-2 py-0.5 rounded">CAMPUS</div>
  </div>
);

export default function VoyageMap() {
  const { data: buses } = useBuses();
  
  // Default Center (Generic City)
  const defaultProps = {
    center: { lat: 12.9716, lng: 77.5946 }, // Bangalore coords as placeholder
    zoom: 12
  };

  return (
    <Layout>
      <div className="relative h-[calc(100vh-8rem)] rounded-3xl overflow-hidden shadow-2xl border border-sapphire/20 bg-gray-100">
        
        {/* Map Overlay Stats */}
        <div className="absolute top-4 left-4 z-10 flex gap-2">
          <div className="bg-white/80 backdrop-blur-md px-4 py-2 rounded-xl border border-white shadow-sm">
            <span className="text-xs text-muted-foreground font-bold uppercase block">Active Fleet</span>
            <span className="text-xl font-display text-sapphire">{buses?.filter(b => b.status === 'active').length || 0}</span>
          </div>
        </div>

        {/* Map Container */}
        <div className="w-full h-full">
          <GoogleMapReact
            bootstrapURLKeys={{ key: "" }} // Leave empty for dev/placeholder mode
            defaultCenter={defaultProps.center}
            defaultZoom={defaultProps.zoom}
            options={{
              styles: [
                { "elementType": "geometry", "stylers": [{ "color": "#f5f5f5" }] },
                { "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] },
                { "elementType": "labels.text.fill", "stylers": [{ "color": "#616161" }] },
                { "elementType": "labels.text.stroke", "stylers": [{ "color": "#f5f5f5" }] },
                { "featureType": "road", "elementType": "geometry", "stylers": [{ "color": "#ffffff" }] },
                { "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#e9e9e9" }] },
                { "featureType": "water", "elementType": "labels.text.fill", "stylers": [{ "color": "#9e9e9e" }] }
              ]
            }}
          >
            <UniMarker lat={12.9716} lng={77.5946} />
            <UserMarker lat={12.9600} lng={77.5800} /> {/* Mock User Loc */}
            
            {buses?.map((bus) => (
              <BusMarker 
                key={bus.id} 
                lat={Number(bus.lat) || 12.98 + (bus.id * 0.01)} // Mock positions if null
                lng={Number(bus.lng) || 77.60 + (bus.id * 0.01)}
                bus={bus} 
              />
            ))}
          </GoogleMapReact>
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur p-4 rounded-xl shadow-lg border border-sapphire/5 text-xs space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-burgundy rounded-full" /> 
            <span className="font-bold text-sapphire">Your Location</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-sapphire rounded-full" /> 
            <span className="font-bold text-sapphire">Active Bus</span>
          </div>
          <div className="flex items-center gap-2">
             <div className="w-3 h-3 bg-ivory border border-sapphire rounded-full" /> 
             <span className="font-bold text-sapphire">Campus</span>
          </div>
        </div>
      </div>
    </Layout>
  );
}
