import { useState } from "react";
import { useLocation } from "wouter";
import { useLogin, useUser } from "@/hooks/use-auth";
import { RydarLogo } from "@/components/RydarLogo";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { data: user, isLoading: isUserLoading } = useUser();
  const { mutate: login, isPending } = useLogin();
  
  const [camuId, setCamuId] = useState("");
  const [password, setPassword] = useState("");

  // Redirect if already logged in
  if (user) {
    setLocation("/dashboard");
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(
      { camuId, password },
      {
        onSuccess: () => {
          setLocation("/dashboard");
        },
        onError: (err) => {
          toast({
            title: "Access Denied",
            description: err.message,
            variant: "destructive",
          });
        },
      }
    );
  };

  if (isUserLoading) return null;

  return (
    <div className="min-h-screen bg-ivory flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] border border-sapphire/5 rounded-full" />
        <div className="absolute top-[-15%] left-[-5%] w-[400px] h-[400px] border border-burgundy/5 rounded-full" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md z-10"
      >
        <div className="bg-white/50 backdrop-blur-xl border border-white/60 shadow-xl rounded-2xl p-8 md:p-12 relative overflow-hidden group">
          
          {/* Top accent line */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-burgundy via-sapphire to-burgundy" />

          <div className="flex flex-col items-center mb-10">
            <div className="w-20 h-20 mb-6">
              <RydarLogo animate={true} />
            </div>
            <h1 className="text-2xl font-display text-sapphire tracking-wider">CAMU ACCESS</h1>
            <p className="text-muted-foreground font-mono text-xs mt-2">SECURE GATEWAY</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-sapphire/70 uppercase tracking-widest pl-1">Camu ID</label>
              <Input 
                value={camuId}
                onChange={(e) => setCamuId(e.target.value)}
                className="bg-white/80 border-sapphire/10 focus:border-sapphire/50 focus:ring-sapphire/20 h-12 font-mono"
                placeholder="Enter ID..."
                required
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-xs font-bold text-sapphire/70 uppercase tracking-widest pl-1">Password</label>
              <Input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-white/80 border-sapphire/10 focus:border-sapphire/50 focus:ring-sapphire/20 h-12"
                placeholder="••••••••"
                required
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-14 bg-sapphire hover:bg-sapphire/90 text-ivory font-display tracking-widest text-lg shadow-lg shadow-sapphire/20 mt-4"
              disabled={isPending}
            >
              {isPending ? <Loader2 className="animate-spin" /> : "AUTHENTICATE"}
            </Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-[10px] text-muted-foreground font-mono">
              AUTHORIZED PERSONNEL ONLY • ENCRYPTED CONNECTION
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
