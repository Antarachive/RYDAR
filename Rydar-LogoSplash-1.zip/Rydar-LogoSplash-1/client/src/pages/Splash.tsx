import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { RydarLogo } from "@/components/RydarLogo";

export default function Splash() {
  const [, setLocation] = useLocation();
  const [exit, setExit] = useState(false);

  useEffect(() => {
    // Hold for 2.5s then trigger exit animation
    const timer = setTimeout(() => {
      setExit(true);
      // Wait for exit animation to finish before navigating
      setTimeout(() => setLocation("/login"), 800);
    }, 2500);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <AnimatePresence>
      {!exit && (
        <motion.div
          className="fixed inset-0 bg-ivory flex flex-col items-center justify-center z-[100]"
          exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            className="w-[40%] max-w-[300px] aspect-square relative flex items-center justify-center"
          >
            <RydarLogo animate={true} className="w-full h-full" />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="mt-12 text-center"
          >
            <h1 className="text-3xl font-display font-bold text-sapphire tracking-[0.2em]">RYDAR</h1>
            <div className="flex items-center gap-2 justify-center mt-2 text-burgundy font-mono text-sm">
              <span className="w-2 h-2 bg-burgundy rounded-full animate-pulse" />
              <span>INITIALIZING BLOCKCHAIN</span>
            </div>
            <div className="flex items-center gap-2 justify-center mt-1 text-sapphire/60 font-mono text-xs">
              <span className="w-1.5 h-1.5 bg-sapphire/60 rounded-full animate-pulse delay-75" />
              <span>CALIBRATING GPS MODULES</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
